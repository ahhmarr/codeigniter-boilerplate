<?php  $this->load->view("includes/lightHeader_view") ?>
<?php  $this->load->view($view) ?>
<?php  $this->load->view("includes/footer_view") ?>