<h2 class="row text-center">worker's re-application</h2>
<hr>
		<?php  echo form_open_multipart('employee/save','class="form-horizontal offset1"') ?>

			<div class="control-group">
				<label for="date" class="control-label">employee ID</label>
				<div class="controls">
				<input  type="number" name="" id="oldEmployeeID" placeholder="employee ID">
				</div>
			</div>
			<input type="hidden" name="empType" value="2">
			<div class="control-group">
				<label for="date" class="control-label">date</label>
				<div class="controls">
				<input class="axBlank" type="text"  id="dateRe" placeholder="date" readonly value="<?php  echo date("M-d-Y") ?>">
				</div>
			</div>
			<!-- <div class="control-group">
				<label class="control-label">status</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="sex" id="Re" value="1">new worker
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="sex" id="Re" value="2">returning worker
					</label>
				</div>
			</div> -->
			<div class="control-group">
				<label for="firstName" class="control-label">first name</label>
				<div class="controls">
				<input class="axBlank" type="text" name="firstName" id="firstNameRe" placeholder="first name">
				</div>
			</div>
			<div class="control-group">
				<label for="lastName" class="control-label">last name</label>
				<div class="controls">
					<input class="axBlank" type="text" name="lastName" id="lastNameRe" placeholder="last name">
				</div>
			</div>
			<div class="control-group">
				<label class="control-label">sex</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="sex" id="Re" value="1">m
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="sex" id="Re" value="2">f
					</label>
				</div>
			</div>
			
			<!-- <div class="control-group">
				<label for="dob" class="control-label">date of birth</label>
				<div class="controls">
					<div id="datetimepicker2Re" class="dateTimePicker" class="input-append">
				    <input data-format="yyyy/MM/dd" name="dob" class="axBlank" type="text"></input>
				    <span class="add-on">
				      <i data-time-icon="icon-time" data-date-icon="icon-calendar">
				      </i>
				    </span>
				  </div>
				</div>
			</div> -->
			<div class="control-group">
				<label for="dob" class="control-label">date of birth</label>
				<div class="controls">
					<input type="text" name="dob"  class="axBlank datePickerUI">
				</div>
			</div>
			<div class="control-group">
				<label for="photo" class="control-label">photo</label>
				<div class="controls">
					<input  type="file" name="photo" class="photo">
				</div>
			</div>
			<!-- <div class="control-group">
				<label for="photo" class="control-label">photo</label>
				<div class="controls">
					<input class="axBlank" type="file" name="photo" id="photoRe">
				</div>
			</div> -->
			<div class="control-group">
				<label for="maritalStatus" class="control-label">marital status</label>
				<div class="controls">
					<select  name="maritalStatus" id="maritalStatusRe">
						<option value="1">married</option>
						<option value="2">single</option>
					</select>
				</div>
			</div>
			<div class="control-group">
				<label for="address" class="control-label">address</label>
				<div class="controls">
					<textarea class="axBlank"  name="address" id="addressRe" rows="5" cols="30" placeholder="address"></textarea>
				</div>
			</div>
			<div class="control-group">
				<label for="zip" class="control-label">zip</label>
				<div class="controls">
					<input class="axBlank axNumber" type="number" name="zip" id="zipRe" placeholder="zip">
				</div>
			</div>
			<div class="control-group">
				<label for="city" class="control-label">city</label>
				<div class="controls">
					<input class="axBlank" type="text" name="city" id="cityRe" placeholder="city" >
				</div>
			</div>
			<div class="control-group">
				<label for="state" class="control-label">state</label>
				<div class="controls">
					<input class="axBlank" type="text" name="state" id="stateRe" placeholder="state" >
				</div>
			</div>
			
			<div class="control-group">
				<label for="pHome" class="control-label">phone number(s)</label>
				<div class="controls">
					<div class="input-prepend">
						<span class="add-on"><i class="icon-home"></i></span>
						<input type="text"  class="input-small axBlank axPhone" name="pHome" id="pHomeRe" placeholder="home">
						
					</div>
					<div class="input-prepend">
						<span class="add-on"><i class="icon-phone"></i></span>
						<input type="text" name="pWork" class="input-small axBlank axPhone" id="pWorkRe" placeholder="work">
						
					</div>
					<div class="input-prepend">
						<span class="add-on"><i class="icon-mobile-phone"></i></span>
						<input type="text" name="pCell" class="input-small axBlank axPhone" id="pCellRe" placeholder="cell">
						
					</div>
				</div>
			</div>
			<div class="control-group">
				<label for="email" class="control-label">email</label>
				<div class="controls">
					<input class="axBlank axEmail" type="email" name="email" id="emailRe" placeholder="email">
				</div>
			</div>
			<div class="control-group">
				<label class="control-label">would you like to serve in the same department?</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="bapIm" id="Re" value="1" data-show="reDepCon">Yes
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="bapIm" id="Re" value="2" data-show="reDepCon">No
					</label>
				</div>
			</div>	
			<div class="control-group hidden-x" id="reDepCon">
				<label for="email" class="control-label">department(s) in which you would like to serve</label>
				<div class="controls">
					<?php  echo $dep1 ?>
					
						<?php  echo $dep2 ?>
					
				</div>
			</div>
			<div class="control-group">
				<label for="member" class="control-label">member of jesus house baltimore since</label>
				<div class="controls">
					<input class="axBlank datePickerUI" type="text" name="member" id="memberRe" placeholder="member since">
				</div>
			</div>
			<div class="control-group">
				<label for="comment" class="control-label">comment</label>
				<div class="controls">
					<textarea   name="comment" id="comment" rows="5" cols="30" placeholder="comment"></textarea>
				</div>
			</div>
			
			<div class="control-group">
				<label for="skills" class="control-label">special skills</label>
				<div class="controls">
					<textarea class="axBlank"  name="skills" id="skillsRe" rows="5" cols="30" placeholder="skills"></textarea>
				</div>
			</div>
			<legend>
				<fieldset>next of kin(emrgency contact)</fieldset>
				
			</legend>
				<div class="control-group">
					<label for="kinName" class="control-label">name</label>
					<div class="controls">
						<input class="axBlank" type="text" name="kinName" id="Re">
					</div>
				</div>
				<div class="control-group">
					<label for="kinPhone" class="control-label">tel</label>
					<div class="controls">
						<input class="axBlank axPhone" type="text" name="kinPhone" id="Re">
					</div>
				</div>
				<div class="control-group">
					<label for="kinRel" class="control-label">relationship</label>
					<div class="controls">
						<input class="axBlank" type="text" name="kinRel" id="Re" >
					</div>
				</div>
				<div class="control-group">
				<label for="kindAddress" class="control-label">address</label>
				<div class="controls">
					<textarea  class="axBlank" name="kindAddress" id="kindAddressRe" rows="5" cols="30" placeholder="address">
					</textarea>
				</div>
			</div>
			
			<div class="control-group">
				
				<div class="controls">
					<input  type="submit" class="btn btn-primary btn-large" value="Submit">
					<input  type="reset" class="btn btn-warning btn-large" value="reset">
				</div>
			</div>
		</form>