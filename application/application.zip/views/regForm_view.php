<script type="text/javascript">
		
</script>




<h2 class="row text-center">Registration application</h2>
<hr>
		<?php  echo form_open_multipart('employee/save','class="form-horizontal offset1"') ?>

			<div class="control-group">
				<label for="date" class="control-label">date</label>
				<div class="controls">
				<input class="axBlank" type="text"  id="date" placeholder="date" readonly value="<?php  echo date("M-d-Y") ?>">
				</div>
			</div>
			<!-- <div class="control-group">
				<label class="control-label">status</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="sex" id="" value="1">new worker
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="sex" id="" value="2">returning worker
					</label>
				</div>
			</div> -->
			<div class="control-group">
				<label for="firstName" class="control-label">first name</label>
				<div class="controls">
				<input class="axBlank" type="text" name="firstName" id="firstName" placeholder="first name">
				</div>
			</div>
			<div class="control-group">
				<label for="lastName" class="control-label">last name</label>
				<div class="controls">
					<input class="axBlank" type="text" name="lastName" id="lastName" placeholder="last name">
				</div>
			</div>
			<div class="control-group">
				<label class="control-label">sex</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="sex" id="" value="1">m
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="sex" id="" value="2">f
					</label>
				</div>
			</div>
			
			<!-- <div class="control-group">
				<label for="dob" class="control-label">date of birth</label>
				<div class="controls">
					<div id="datetimepicker2" class="input-append">
				    <input data-format="yyyy/MM/dd" class="axBlank" name="dob" type="text"></input>
				    <span class="add-on">
				      <i data-time-icon="icon-time" data-date-icon="icon-calendar">
				      </i>
				    </span>
				  </div>
				</div>
			</div> -->
			<div class="control-group">
				<label for="dob" class="control-label">date of birth</label>
				<div class="controls">
					<input type="text" name="dob"  class="axBlank datePickerUI">
				</div>
			</div>
			<div class="control-group">
				<label for="photo" class="control-label">photo</label>
				<div class="controls">
					<input  type="file" name="photo" id="photo">
				</div>
			</div>
			<div class="control-group">
				<label for="maritalStatus" class="control-label">marital status</label>
				<div class="controls">
					<select  name="maritalStatus" id="maritalStatus">
						<option value="1">married</option>
						<option value="2">single</option>
					</select>
				</div>
			</div>
			<div class="control-group">
				<label for="address" class="control-label">address</label>
				<div class="controls">
					<textarea class="axBlank"  name="address" id="address" rows="5" cols="30" placeholder="address"></textarea>
				</div>
			</div>
			<div class="control-group">
				<label for="zip" class="control-label">zip</label>
				<div class="controls">
					<input class="axBlank axNumber" type="number" name="zip" id="zip" placeholder="zip">
				</div>
			</div>
			<div class="control-group">
				<label for="city" class="control-label">city</label>
				<div class="controls">
					<input class="axBlank" type="text" name="city" id="city" placeholder="city" >
				</div>
			</div>
			<div class="control-group">
				<label for="state" class="control-label">state</label>
				<div class="controls">
					<input class="axBlank" type="text" name="state" id="state" placeholder="state" >
				</div>
			</div>
			
			<div class="control-group">
				<label for="pHome" class="control-label">phone number(s)</label>
				<div class="controls">
					<div class="input-prepend">
						<span class="add-on"><i class="icon-home"></i></span>
						<input type="text"  class="input-small axBlank axPhone" name="pHome" id="pHome" placeholder="home">
						
					</div>
					<div class="input-prepend">
						<span class="add-on"><i class="icon-phone"></i></span>
						<input type="text" name="pWork" class="input-small axBlank axPhone" id="pWork" placeholder="work">
						
					</div>
					<div class="input-prepend">
						<span class="add-on"><i class="icon-mobile-phone"></i></span>
						<input type="text" name="pCell" class="input-small axBlank axPhone" id="pCell" placeholder="cell">
						
					</div>
				</div>
			</div>
			<div class="control-group">
				<label for="email" class="control-label">email</label>
				<div class="controls">
					<input class="axBlank axEmail" type="email" name="email" id="email" placeholder="email">
				</div>
			</div>
			<div class="control-group">
				<label for="email" class="control-label">department(s) in which you would like to serve</label>
				<div class="controls">
					<?php  echo $dep1 ?>
					
						<?php  echo $dep2 ?>
					
				</div>
			</div>
			<div class="control-group">
				<label for="member" class="control-label">member of jesus house baltimore since</label>
				<div class="controls">
					<input class="axBlank" type="text" name="member" id="member" placeholder="">
				</div>
			</div>
			<div class="control-group">
				<label for="dSalvation" class="control-label">date &amp; place of salvation</label>
				<div class="controls">
					<input class="axBlank" type="text" name="dSalvation" id="dSalvation" placeholder="date of salvation">
					<input class="axBlank" type="text" name="pSalvation" id="pSalvation" placeholder="place of salvation">
				</div>
			</div>
			<div class="control-group">
				<label for="placeOW" class="control-label">former place of worship</label>
				<div class="controls">
					<input class="axBlank" type="text" name="placeOW" id="placeOW" placeholder="place of worship">
				</div>
			</div>
			<div class="control-group">
				<label for="ministry" class="control-label">in what ministries did you serve?</label>
				<div class="controls">
					<input class="axBlank" type="text" name="ministry" id="ministry" placeholder="ministries">
				</div>
			</div>
			<div class="control-group">
				<label class="control-label">have you been baptized in by the holy spirit?</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="bapHl" id="" value="1" >Yes
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="bapHl" id="" value="2">No
					</label>
				</div>
			</div>
			<div class="control-group">
				<label class="control-label">Have you been baptized by immersion?</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="bapIm" id="" value="1" data-show="placeObap">Yes
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="bapIm" id="" value="2" data-hide="placeObap">No
					</label>
				</div>
			</div>			
			<div class="control-group hidden-x" id="placeObap">
				<label for="wBaptised" class="control-label">where did you get baptized?</label>
				<div class="controls">
					<input class="axBlank" type="text" name="wBaptised" id="wBaptised" placeholder="place of baptism">
				</div>
			</div>
			<div class="control-group">
				<label class="control-label">
					have you attended believer’s academy foundation class in jesus house baltimore?
				</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="belAcademy" id="" value="1" data-show="graduateCon">Yes
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="belAcademy" id="" value="2" data-hide-radio="graduateCon">No
					</label>
				</div>
			</div>
			<div class="control-group hidden-x" id="graduateCon">
				<label class="control-label">
					did you take the examination and graduate? 
				</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="belAcademyEx" id="" value="1">Yes
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="belAcademyEx" id="" value="2">No
					</label>
				</div>
			</div>
			<div class="control-group">
				<label class="control-label">
					do you belong to a cell group? 
				</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="cellGroup" id="" value="1" data-show="cellGroupCon">Yes
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="cellGroup" id="" value="2" data-hide="cellGroupCon">No
					</label>
				</div>
			</div>
			<div class="control-group hidden-x" id="cellGroupCon">
				<label for="cellGroupName" class="control-label">which cell group do you belong to?</label>
				<div class="controls">
					<input class="axBlank" type="text" name="cellGroupName" id="cellGroupName" placeholder="cell group name">
				</div>
			</div>
			<div class="control-group">
				<label class="control-label ">
					do you believe in tithing as a scriptural commandment?
				</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="script" id="" value="1" data-show="titheCon">Yes
					</label>
					<label for="" class="radio inline">
						<input class="axBlank" type="radio" name="script" id="" value="2" data-hide-radio="titheCon">No
					</label>
				</div>
			</div>
			<div class="control-group hidden-x" id="titheCon">
				<label class="control-label">
					Do you pay your tithes regularly?
				</label>
				<div class="controls">
					<label for="" class="radio inline">
						<input type="radio" class="axBlank"  name="tithe" id="" value="1">Yes
					</label>
					<label for="" class="radio inline">
						<input type="radio" class="axBlank"  name="tithe" id="" value="2">No
					</label>
				</div>
			</div>
			
			<div class="control-group">
				<label for="skills" class="control-label">special skills</label>
				<div class="controls">
					<textarea class="axBlank"  name="skills" id="skills" rows="5" cols="30" placeholder="skills"></textarea>
				</div>
			</div>
			<legend>
				<fieldset>next of kin(emrgency contact)</fieldset>
				
			</legend>
				<div class="control-group">
					<label for="kinName" class="control-label">name</label>
					<div class="controls">
						<input class="axBlank" type="text" name="kinName" id="">
					</div>
				</div>
				<div class="control-group">
					<label for="kinPhone" class="control-label">tel</label>
					<div class="controls">
						<input class="axBlank axPhone" type="text" name="kinPhone" id="">
					</div>
				</div>
				<div class="control-group">
					<label for="kinRel" class="control-label">relationship</label>
					<div class="controls">
						<input class="axBlank" type="text" name="kinRel" id="" >
					</div>
				</div>
				<div class="control-group">
				<label for="kindAddress" class="control-label">address</label>
				<div class="controls">
					<textarea  class="axBlank" name="kindAddress" id="kindAddress" rows="5" cols="30" placeholder="address">
					</textarea>
				</div>
			</div>
			<div class="control-group">
				
				<div class="controls">
					<input  type="submit" class="btn btn-primary btn-large" value="Submit">
					<input  type="reset" class="btn btn-warning btn-large" value="reset">
				</div>
			</div>
		</form>