<div>
	<div class="span10 offset1 ui-white padding-mid top-buffer-largest rounded-all">
		<h2>sorry you are not authorized for this page</h2>
		<?php  echo  anchor('log/index','go back','class="btn btn-primary"') ?>
	</div>
</div>
