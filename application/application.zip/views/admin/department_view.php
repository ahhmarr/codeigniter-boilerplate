<div class=" span11 offset1 ui-white rounded-all padding-mid">
	<?php  
       echo form_open('admin/department',array("class"=>"form-inline"))


	 ?>
	 <input type="text" name="depName" id="" class="axBlank" placeholder="department name">
	 <input type="submit" name="" id="" class="btn btn-primary" value="add department">
	</form>
	<hr>
	<?php  

     echo $dep;
	 ?>
</div>