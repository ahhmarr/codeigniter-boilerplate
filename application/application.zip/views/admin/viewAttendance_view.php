<div class=" span11 offset1 ui-white rounded-all padding-mid">
	<h2>view attendance</h2>
	<hr>
	<div id="datetimepicker2" class="input-append pull-left">
	    <input data-format="yyyy-MM-dd" class="axBlank mousetrap" type="text" name="dateTime" id="dateTime"
	    		value="<?php echo date('Y-m-d') ?>" autocomplete="off" placeholder="year/month/day">
	    <span class="add-on">
	      <i data-time-icon="icon-time" data-date-icon="icon-calendar" class="icon-calendar">
	      </i>
	    </span>
	   
	</div>
	<div class="pull-left">
		<input type="button" class="btn btn-primary" id="viewAttend" value="view"> 
	</div>
	<div class="clearfix"></div>
	<div id="atCon">
		
	</div>
</div>
<script type="text/javascript">
	
		$(function(){
			
			
			
			$("#viewAttend").click(function()
			{
			   url="<?php  echo site_url('admin/ajaxAttendance/') ?>/"+$("#dateTime").val();
			   	console.log(url);
			   	$.ajax({url:url,success:function(r){
			   				console.log(r);
			   				r=$.trim(r);
			   				if(!r)
			   					r="<h3 class='row offset2'>Sorry Attendance Not Recorded for this day</h3>";
			   				$('#atCon').html(r);
			   	}});
			})
		});
</script>
