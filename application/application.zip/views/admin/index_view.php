<script type="text/javascript">
//Get context with jQuery - using jQuery's .get() method.
	$(function(){
		
		var ctx = $("#presentStat").get(0).getContext("2d");
		var data = {
					labels : $("#dataLabel").val().split(","),
					datasets : [
								{
									opacity:".2",
									fillColor : "rgba(200,255,197,0.3)",
									strokeColor : "#68CD64",
									pointColor : "#146B10",
									pointStrokeColor : "#fff",
									data : $("#dataSet").val().split(",")
								}
								]
					};

var options={
	
}
var c=new Chart(ctx).Line(data,options);

var ctx2 = $("#userStat").get(0).getContext("2d");
		var data = {
					labels : $("#userLabel").val().split(","),
					datasets : [
								{
									opacity:".2",
									fillColor : "rgba(255,166,166,0.3)",
									strokeColor : "#FF6187",
									pointColor : "#146B10",
									pointStrokeColor : "#fff",
									data : $("#userSet").val().split(",")
								}
								]
					};

var options={
	
}
var d=new Chart(ctx2).Bar(data,options);
	});
</script>
<input type="hidden" id="dataLabel" value="<?php  echo $val["month"] ?>">
<input type="hidden" id="dataSet" value="<?php  echo $val["value"] ?>">
<input type="hidden" id="userLabel" value="<?php  echo $usrStat["month"] ?>">
<input type="hidden" id="userSet" value="<?php  echo $usrStat["value"] ?>">
<div class=" span11 offset1 ui-white rounded-all padding-mid">
	<h2>dashboard</h2>
	<hr>
	<div class="row padding top-buffer-largest">
		<div class="span5 box-border-green">
			<div class="span12 text-center">
				<div class="ui-green ui-text-white padding-mid pull-left  row">workers present</div>
			</div>
			<canvas height="150" width="460" id="presentStat" ></canvas>
		</div>
		<div class="span5 box-border-pink">
			<div class="span12 text-center">
				<div class="ui-pink ui-text-white padding-mid pull-left  row">user added</div>
			</div>
			<canvas height="150" width="460" id="userStat" ></canvas>
		</div>
	</div>
</div>