<script type="text/javascript">
		$(function(){
			$("#filtr").click(function()
			{
				$("#filter").slideToggle();
			})
		});
</script>
<div class=" span12 ui-white rounded-all">
	<h2 class="row text-center">worker details</h2>
	<h3 class="row text-center">
		<button class="btn" id="filtr">filters</button></h3>
		<?php  echo form_open("admin/listEmployee",'class="form-inline row offset2 hidden-x" id="filter"') ?>
		<div class="row" >
		
		<input id="filterName" type="text" name="filterName" placeholder="name">
		<label for="filterM">male </label> <input id="filterM" type="radio" name="filterSex" value="1">
		<label for="filterF">female </label> <input id="filterF" type="radio" name="filterSex" value="2">
		<label for="filterMar">marital status </label>
		<select name="filterMar" id="filterMar" class="input-small">
			<option value=""></option>
			<option value="1">married</option>
			<option value="2">single</option>
		</select>
		<label for="filterAppType">application type </label>
		<select name="filterAppType" id="filterAppType" class="input-small">
			<option value=""></option>
			<option value="1">new</option>
			<option value="2">re-apply</option>
		</select>
		<input id="addedFrom" type="text" name="addedFrom" class="input-small" placeholder="joining from">
		<input id="addedTo" type="text" name="addedTo" class="input-small" placeholder="joining to">
		
	</div>
	<div class="row top-buffer-small">
		<label for="filterDepName">department name</label>
		<?php  echo $dep ?>
		<input id="filterZipCode" type="number" name="filterZipCode" class="input-small" placeholder="zipcode">
		<input id="filterCity" type="text" class="input-small" name="filterCity" placeholder="city">
		<input id="filterState" type="text" class="input-small" name="filterState" placeholder="state">
		<input id="filterEmail" type="email" class="input-small" name="filterEmail" placeholder="emails">

		<input type="submit" name="" id="" class="btn btn-primary" >
		<input type="reset" name="" id="" class="btn btn-warning" >
	</div>
	</form>
	<div class="pull-right span2"><?php  echo anchor("admin/listEmployee/toEx",img(base_url().'img/xcl.png')) ?></div>
	<div class="span10 padding-mid">
		
		<?php if(isset($records))echo $records;?>
	</div>
</div>