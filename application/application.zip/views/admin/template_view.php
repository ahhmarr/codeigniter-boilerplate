<?php  $this->load->view("admin/includes/header_view") ?>
<?php  $this->load->view($view) ?>
<?php  $this->load->view("admin/includes/footer_view") ?>