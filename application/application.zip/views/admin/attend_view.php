<div class=" span11 offset1 ui-white rounded-all padding-mid">
<h2>attendance</h2>
<hr>
    		
<?php  echo form_open('admin/saveAttend'); ?>
<div id="datetimepicker2" class="input-append">
    <input data-format="yyyy/MM/dd" class="axBlank mousetrap" type="text" name="dateTime"
    		value="<?php echo date('Y/m/d') ?>" autocomplete="off" placeholder="year/month/day">
    <span class="add-on">
      <i data-time-icon="icon-time" data-date-icon="icon-calendar" class="icon-calendar">
      </i>
    </span>
</div>

	<?php  
		$sn=0;
    	foreach ($attend as $row) {
    		if($row->firstName=="" && $row->lastName=="")
    			continue;
    		$name="at".$row->id;
    		$img=$row->img;
       		?>

    		<div class="row top-buffer-small">
    			<input type="hidden" name="emp[]" value="<?php echo  $row->id ?>">
    			<div class="span1"><?php echo ++$sn ?></div>
    			<div class="span1"><?php  echo img("img/pic/".$img) ?></div>
    			<div class="span3"><?php echo $row->firstName.' '.$row->lastName ?></div>
	    		<div class="span3">
	    			<input class="hidden-x" type="radio" value="1" id="p<?php echo $row->id?>" name="<?php echo $name ?>"> 
    				<label class=" padding-small checkLabel radioHidden ui-blue text-center" 
    						for="p<?php echo $row->id?>">present</label>
					
		    	</div>
	    		<div class="span3">
	    			<input class="hidden-x" type="radio" value="2" id="a<?php echo $row->id?>" name="<?php echo $name ?>"> 
		    		<label class=" padding-small checkLabel radioHidden ui-red text-center" 
		    				for="a<?php echo $row->id?>">absent</label>
	    		</div>
    		</div>

    	<?php }
	 ?>
		<div class="top-buffer-large text-center">
			<input type="submit" name=""  class="btn btn-primary" >
		<input type="reset" name="" id="" class="btn btn-warning">
		</div>
	</form>
</div>