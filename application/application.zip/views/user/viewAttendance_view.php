<?php  
$p=$defAt["p"];
$a=$defAt["a"];
$t=$p+$a;
$abP=($t)?round($a/$t*100):0;
$prP=($t)?round($p/$t*100):0;
 ?>
<div class=" span11 offset1 ui-white rounded-all padding-mid">
	<h2>attendance summary <?php  echo $defAt["year"] ?></h2>
	<hr>
	<?php  
      echo form_open('user/viewAttendance','class="form-horizontal"');
	 ?>
	 <?php  echo ' '.$year ?>
	<input type="submit" name="" id="viewAttend" class="btn btn-primary" value="view attendance">
</form>
	<div class="clearfix"></div>
	<div id="atCon">
		<?php  echo $defAt["table"] ?>
	</div>
	<div class="row">
		<div class="span2">available days :<?php  echo $t ?></div>
		<div class="span2">total day(s) present:<?php  echo $p ?></div>
		<div class="span2">total day(s) absent :<?php  echo $a ?></div>
		<div class="span2">present %age :<?php  echo $prP ?></div>
		<div class="span2">absent %age :<?php  echo $abP ?></div>

	</div>
</div>
<script type="text/javascript">
	
		$(function(){
			$("#yearMonth").datepicker({
				changeYear:true,
				changeMonth:true,
				changeDay:false
			})
			
		});
</script>
