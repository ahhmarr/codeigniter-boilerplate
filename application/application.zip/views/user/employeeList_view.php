<script type="text/javascript">
		$(function(){
			$("#filtr").click(function()
			{
				$("#filter").slideToggle('slow');
			})
		});
</script>
<div class=" span11 offset1 ui-white rounded-all">
	<h2 class="row text-center">employee details</h2>
	<div class="row" >
		<h3 class="row text-center"><button class="btn" id="filtr">filters</button></h3>
		<?php  echo form_open("admin/listEmployee",'class="form-inline row offset1 hidden-x" id="filter"') ?>
		<input id="filterName" type="text" name="filterName" placeholder="name">
		<label for="filterM">male </label> <input id="filterM" type="radio" name="filterSex" value="1">
		<label for="filterF">female </label> <input id="filterF" type="radio" name="filterSex" value="2">
		<label for="filterMar">marital status </label>
		<select name="filterMar" id="filterMar" class="input-small">
			<option value=""></option>
			<option value="1">married</option>
			<option value="2">single</option>
		</select>
		<input id="addedFrom" type="text" name="addedFrom" class="input-small" placeholder="joining from">
		<input id="addedTo" type="text" name="addedTo" class="input-small" placeholder="joining to">
		<input type="submit" name="" id="" class="btn btn-primary" >
		<input type="reset" name="" id="" class="btn btn-warning" >
	</form>
	</div>
	<div class="span10 padding-mid">
		<?php if(isset($records))echo $records;?>
	</div>
</div>