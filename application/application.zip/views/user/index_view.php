<script type="text/javascript">
//Get context with jQuery - using jQuery's .get() method.
	$(function(){
		
		var ctx = $(".attendance").get(0).getContext("2d");

	var data = {
	labels : ["January","February","March","April","May","June","July"],
	datasets : [
		
		{
			fillColor : "rgba(151,187,205,0.5)",
			strokeColor : "rgba(151,187,205,1)",
			pointColor : "rgba(151,187,205,1)",
			pointStrokeColor : "#fff",
			data : [10,20,25,19,3,15,31]
		}
	]
	
};
var c=new Chart(ctx).Line(data);
	});
</script>
<div class=" span11 padding-mid offset1 ui-white rounded-all">
<h2>hello <?php  echo $user->firstName ?></h2>
<hr>
<div class="row">
	<h2 class="offset1">attendance stats</h2 class="offset1">
	<div class="span4">
		<canvas height="400" width="800" class="attendance" id="thisMonth"></canvas>
	</div>
	
	
</div>
</div>