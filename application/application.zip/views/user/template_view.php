<?php  $this->load->view("user/includes/header_view") ?>
<?php  $this->load->view($view) ?>
<?php  $this->load->view("user/includes/footer_view") ?>