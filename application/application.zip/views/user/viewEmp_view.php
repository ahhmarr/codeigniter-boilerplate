<?php  
$em=$emp[0];$sx=array(1=>"male",2=>"female");
$age=date_diff(date_create(date("Y-m-d")),date_create($em->dob));
$ag=$age->format("%y years");
$empID=$em->id;

?>
<div class=" span11 offset1 ui-white rounded-all">
	<h2 class="row offset1"><?php  echo $em->firstName.' '.$em->lastName ?></h2>
	<hr>
	<div class="pull-left span2">
		<?php  echo img(array("src"=>APPPATH."../img/pic/$em->img","height"=>"200","width"=>"200")) ?>
	</div>
	
	
	<div class="row  top-buffer-large pull-right">
		<div class="span4 pull-right"><?php  echo $sx[$em->sex] ?></div>
		<div class="span4 pull-right">sex</div>
	</div>
	<div class="row  top-buffer-large pull-right">
		<div class="span4 pull-right"><?php  echo ($em->maritalStatus)?"married":"single" ?></div>
		<div class="span4 pull-right">marital status</div>
	</div>
	<div class="row  top-buffer-large pull-right">
		<div class="span4 pull-right"><?php  echo $em->dob ?></div>
		<div class="span4 pull-right">date of birth</div>
	</div>
	<div class="row  top-buffer-large pull-right">
		<div class="span4 pull-right"><?php  echo date("Y-M-d",strtotime($em->added)) ?></div>
		<div class="span4 pull-right">date of joining</div>
	</div>
	<div class="row  top-buffer-large pull-right">
		<div class="span4 pull-right"><?php  echo $em->dep1.','.$em->dep2 ?></div>
		<div class="span4 pull-right">department<span class="smallCase">(s)</span></div>
	</div>
	<div class="row top-buffer-large  pull-right">
		<div class="span4  pull-right">
			<p><?php  echo $em->address?></p>
			<p><?php  echo $em->city.','.$em->state.' '.$em->zip  ?></p>
			<p><?php  echo $em->pHome.','.$em->pWork.','.$em->pCell ?></p>
			<p class="smallCase"><?php  echo $em->email ?></p>


		</div>
		<div class="span4  pull-right">contact details</div>
	</div>
	<div class="row top-buffer-large  pull-right">
		<div class="span4  pull-right">view atendance</div>
		<div class="span4  pull-right">attendance</div>
	</div>
	
</div>