<h2>Create a new account</h2>
<div class="row top-buffer-largest">
	<div class="span6 ">
		<?php $attrib=array("class"=>"form-horizontal")?>
		<?php  echo form_open('login/register',$attrib) ?>
			<div class="control-group">
				<label for="firstName" class="control-label">first name</label>
				<div class="controls">
					<input type="text" name="firstName">
				</div>
			</div>
			<div class="control-group">
				<label for="userName" class="control-label">user name</label>
				<div class="controls">
					<input type="text" name="userName" id="">
				</div>
			</div>
			<div class="control-group">
				<label for="password" class="control-label">password</label>
				<div class="controls">
					<input type="text" name="password" id="">
				</div>
			</div>
			<div class="control-group">
				<div class="controls">
					<input type="submit" class="btn btn-primary" name="" id="">
				</div>
			</div>
		</form>
	</div>

</div>
