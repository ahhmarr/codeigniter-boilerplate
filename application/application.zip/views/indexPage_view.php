<h2> Welcome to the DreamTeam Portal</h2>
<hr/>
<p id="banImage">
	<img src="<?php  echo base_url() ?>img/ban1.jpg"  alt="">
</p>
<br><br>
<p class="content-text">
	The effectiveness of Jesus House Baltimore in meeting the spiritual and other needs of our members is based 
	largely on the selfless and voluntary commitment of over 300 people, who make up the workforce of the church.
</p>
<br>
<p class="content-text">
Popularly known as ‘The Dream Team’, these workers give their time weekly to run various departments and ministries that are
 cogent to ensuring an impactful worship experience.
Guided by the vision of the church, the activities of these volunteers are coordinated by a leadership structure 
made up of pastors,
deacons, ministers and Heads of Departments.
</p><br>
<p class="content-text">
The church’s administration is coordinated by the church office staff who are committed to meeting the objectives of the organization.

Our ministries and departments are designed to cater to specific needs of our members and the community.
The Directorate of ministries is the central resource point for ministry and departmental leaders.

</p><br>

	<div class="span12">
		<ul class="thumbnails text-center">
            	<li class="span3">
                	<div class="thumbnail cursor-pointer border-none prlx"  data-target="page2">
                    	<div class="icon_round">
                        	<i class="icon-user"></i>
                        </div><!--/icon-->
                        <div class="caption">
                        	<h3>Join now</h3>
                            <p class="content-text">for submitting a fresh application </p>
                        </div><!--/caption-->
                    </div><!--/thumbnail cursor-pointer border-none-->
                </li>
                <li class="span3">
                	<div class="thumbnail cursor-pointer border-none prlx"  data-target="page1">
                    	<div class="icon_round">
                        	<i class="icon-lock"></i>
                        </div><!--/icon-->
                        <div class="caption">
                        	<h3>login</h3>
                            <p class="content-text">if you  already submitted the application and  have your login credentials</p>
                        </div><!--/caption-->
                    </div><!--/thumbnail cursor-pointer border-none-->
                </li>
                <li class="span3">
                	<div class="thumbnail cursor-pointer border-none prlx" data-target="page4">
                    	<div class="icon_round">
                        	<i class="icon-group"></i>
                        </div><!--/icon-->
                        <div class="caption">
                        	<h3>re-apply</h3>
                            <p class="content-text">for the candidates who wish to join jesus house of baltimore again</p>
                        </div><!--/caption-->
                    </div><!--/thumbnail cursor-pointer border-none-->
                </li>
                               
            </ul>
	</div>

