<?php  $this->load->view("includes/header_view") ?>
<?php  $this->load->view($view) ?>
<?php  $this->load->view("includes/footer_view") ?>