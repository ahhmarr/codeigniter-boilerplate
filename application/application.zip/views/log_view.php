
<div id="page1">
	
	<div id="wrapper">

	<?php  echo form_open('log/auth','class="login-form"') ?>
	
		<div class="header">
		<h1>Login Form</h1>
		
		</div>

		<div class="content">
		<input name="username" type="text" class="input username" 
				placeholder="Username" value="<?php echo set_value("username") ?>"/>
		<div class="user-icon"></div>
		<input name="password" type="password" class="input password" placeholder="Password"  />
		<div class="pass-icon"></div>		
		</div>

		<div class="footer">
		<input type="submit" name="submit" value="Login" class="button" />
		<input type="button" name="submit" value="Register" id="reg" class="prlx register" data-target="page2" />
		</div>
	</form>
</div>
</div>

<div id="page2">
	
	<div class="span10 offset1 ui-white padding-mid top-buffer-largest rounded-all">
		<?php $this->load->view("regForm_view"); ?>
		
	</div>


</div>
<div id="page3">
	
	<div class="span10 offset1 ui-white padding-mid top-buffer-largest rounded-all">
		<?php $this->load->view("indexPage_view.php") ?>
	</div>
</div>
<div id="page4">
	
	<div class="span10 offset1 ui-white padding-mid top-buffer-largest rounded-all">
		<?php $this->load->view("reRegForm_view.php"); ?>
	</div>
</div>


