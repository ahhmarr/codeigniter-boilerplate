<?php  
class User extends CI_Controller{
	 var $viewPath,$template;

	function __construct()
	{
    	parent::__construct();
    	$this->_checkAuth();
    	$this->viewPath="user/";
    	$this->template="user/template_view";
	}

	function _checkAuth()
	{
		if($this->session->userdata("who"))
		{
            if($this->session->userdata("who")==1)
            	redirect("/admin/");

		}
		else
		{
			redirect("/log/unauth");
		}
	}
	function index()
	{
		$this->load->model('employee');
		$data['user']=$this->employee->returnEmployee(array("id"=>$this->session->userdata("empID")));
		$data['view']=$this->viewPath."index_view";
		$this->load->view($this->template, $data);
	}
	function logout()
	{
		$this->session->sess_destroy();
		redirect('log/index');
	}
	function profile()
	{
		$data=array();
		$empID=$this->uri->segment(3);
		$data['emp']=$this->basic_model->view("tbl_employee",array("id"=>$empID));
		$data['view']="user/viewEmp_view";
		$this->load->view("user/template_view",$data);
	}
	function viewAttendance()
	{
		$this->load->model("various","vr");
		$data["year"]=$this->vr->yearSelect();
		$data["month"]=$this->vr->monthSelect();
		$data["defAt"]=$this->vr->defAt();
		$data["view"]="user/viewAttendance_view";
		$this->load->view("user/template_view",$data);

	}
} ?>