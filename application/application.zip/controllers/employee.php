<?php  
class Employee extends CI_Controller
{
  	function save()
  	{
  		$d=$this->basic_model->_fields($_POST);
      $empID=$this->basic_model->insert("tbl_employee",$d);
  		if($empID)
      {
        $firstName=str_replace(" ","",$this->input->post("firstName"));
        $firstName=trim($firstName);
        $no=rand(1212,9876);
        $userName=$firstName.$no;
        $this->welcomeEmail($userName);
        $this->basic_model->insertOther("users",array(
                  "userName"=>$userName,
                  "added"=>date("Y-m-d h:i:s"),
                  "password"=>md5("123456"),
                  "empID"=>$empID
          ));
      }
      $data['view']=($empID)?'aplSuc_view':'aplErr_view';
      $this->load->view("template_view",$data);

  	}
  	function attendance()
  	{
  		
  	}
    function welcomeEmail($userName)
    {
      $headers = "From: no-reply@jesushouseofboltimore.com \r\n";
      $headers .= "MIME-Version: 1.0\r\n";
      $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
      $subj="welcome to jesus house of baltimore";
      $msg=<<<HTML
      <h2>welcome to jesus house of baltimore</h2> \n
      user name :<b>$userName</b> <br>
      password : <b>123456</b> \n <br>
HTML;
        mail($this->input->post("email"), $subj, $msg,$headers);
        
     
    }

}

 ?>