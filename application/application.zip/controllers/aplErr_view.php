<div id="page2">
	<div class="span10 offset1 ui-white padding-mid top-buffer-largest rounded-all">
		<h2>some error </h2>
		<?php  echo  anchor('log/index','go back','class="btn btn-primary"') ?>
	</div>
</div>
