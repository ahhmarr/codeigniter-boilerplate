<?php  
class Log extends CI_Controller {
	
	function __construct()
	{
     parent::__construct();
     $this->_checkAuth();
	}
	function _checkAuth()
	{
		if($this->session->userdata("who"))
		{
			redirect("/user/");
		}
	}
	public function index()
	{
		$data=array("view"=>"log_view");

		$data['dep1']=$this->basic_model->selectDep("dep1",'class="axBlank"');
		$data['dep2']=$this->basic_model->selectDep("dep2");
		$this->load->view("template_view",$data);
	}
	function unauth()
	{
		$this->load->view("lightTemplate_view",array("view"=>"unauth_view"));
	}
	function auth()
	{
		$data=array(
			"username"=>$this->input->post("username"),
			"password"=>md5($this->input->post("password"))
			);
		$this->load->model("authentication");
		$view=array();
		if($this->authentication->verify($data))
		{
			$who=$this->session->userdata("who");
			$rdr=($who==1)?"admin":"user";
			redirect("/$rdr/");
		}
		else
		{
			$this->index();
		}
		
	}
}