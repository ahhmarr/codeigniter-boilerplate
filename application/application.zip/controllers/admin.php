<?php  
class Admin extends CI_Controller{
 	function __construct()
 	{
 		
 		parent::__construct();
 		$this->_isAdminLogedIn();
 	}

	function _isAdminLogedIn()
	{

		if($this->session->userdata("who"))
			{
				if($this->session->userdata("who")!=1)
					redirect("/log/unauth");
			}
			else
			{
				redirect("/log/unauth");
			}

	}
	function logout()
	{
		$this->session->sess_destroy();
		redirect("/log/index");
	}
	function index($data=array())
	{
		$this->load->model("various","vr");
		$val=$this->vr->label();
		$usrStat=$this->vr->userStat();
		$data["usrStat"]=$usrStat;
		$data["val"]=$val;
		$data['view']="admin/index_view";
		$this->load->view('admin/template_view',$data);
	}
	function listEmployee($action=null)
	{

		$data=array();
		$this->load->model("employee");
		$data['dep']=$this->basic_model->selectDep("filterDepName",'class="input-large"');

		if($record=$this->employee->listEmployee())
			{
			
				$data["records"]=$this->genEmployeeTable($record);
			}
		else
		{
			$data['records']="<h2>no records found</h2>";
		}
		if(!$action)
		{$data["view"]="admin/employeeList_view";
				$this->load->view("admin/template_view",$data);
				return $data;}
		else if($action=="toEx")
		{
			$this->load->library("excel");
			$this->excel->to_excel_from_table($data["records"],date("Y-m-d")."_employee report");
		}
		
		
	}
	function genEmployeeTable($records)
	{
		$c=0;
		$tmpl=array("table_open"=>'<table class="dataTable table table-condensed table-hover">');

		$heading=array("s.no","name","app type","sex","phone","department","added on","<div class='noPrint'>action</div>");
		$this->load->library("table");
		$this->table->set_template($tmpl);
		$sex=array(0=>"",1=>"male",2=>"female");
		$type=array(0=>"",1=>"new",2=>"re-app");
		$this->table->set_heading($heading);
		foreach($records as $r)
		{
			$view=anchor("admin/viewEmployee/".$r->id,"view");
			$btn=<<<BTN
			<div class="btn-group noPrint ">
				<button class="btn btn-info">$view</button>
				<button class="btn dropdown-toggle btn-info" data-toggle="dropdown">
					<span class="caret"></span>
				</button>
				<!-- <ul class="dropdown-menu">
					<li><a href="">view attendance</a></li>
					<li><a href="">view attendance</a></li>
					<li><a href="">view attendance</a></li>
					<li><a href="">view attendance</a></li>
					
				</ul> -->
			</div>
BTN;
			$dep=trim($r->dep1Name.','.$r->dep2Name,",");
			$row=array(++$c,$r->firstName.' '.$r->lastName,$type[$r->empType],$sex[$r->sex],
						$r->pWork,$dep,date("M/d/Y",strtotime($r->added)),$btn);
			$this->table->add_row($row);

		}
		return $this->table->generate();
	} 
	function attendance()
	{
		$this->load->model("employee");
		$data['attend']=$this->basic_model->view("tbl_employee",array("enable"=>1,"deleted"=>0));
		$data['view']="admin/attend_view";
		$this->load->view("admin/template_view",$data);

	}
	function viewAttendance()
	{
		$data['view']="admin/viewAttendance_view";
		$this->load->view("/admin/template_view",$data);
	}
	function enableDisableEmployee()
	{

	}
	function viewEmployee()
	{
		$data=array();
		$empID=$this->uri->segment(3);
		$d=$this->basic_model->view("tbl_employee",array("id"=>$empID));
		$data['emp']=$d;
		$de=$d[0];
		$dep1=$de->dep1;
		$dep2=$de->dep2;
		$dep11=$dep22="";
		$dep=$this->basic_model->view("tbl_department",array("id"=>$dep1));
		foreach ($dep as $row) {
			$dep11=$row->depName;
		}
		$dep=$this->basic_model->view("tbl_department",array("id"=>$dep2));
		foreach ($dep as $row) {
			$dep22=$row->depName;
		}
		$dep=$this->basic_model->view("tbl_department",array("id"=>$dep1));
		$data['dep1']=$dep11;
		$data['dep2']=$dep22;
		$data['view']="admin/viewEmp_view";
		$this->load->view("admin/template_view",$data);
	}
	function saveAttend()
	{
		
		$this->load->model("employee");
		$data['msg']=$this->employee->saveAttend()?"success":"error";
		$this->index($data);
		
	}
	function ajaxAttendance()
	{
		$this->load->model("employee");
		$data['record']=$this->employee->viewAttend();
	}
	function disable()
	{
		$this->basic_model->update("tbl_department",array("enable"=>0));
		$this->department();
	}
	function enable()
	{
		$this->basic_model->update("tbl_department",array("enable"=>1));
		$this->department();
	}
	function delete()
	{
		$this->basic_model->update("tbl_department",array("deleted"=>1));
		$this->department();
	}
	function department()
	{
		$this->load->model("employee");
		$data['view']="admin/department_view";
		$rec=$this->employee->fetchNSaveDep();
		$tmpl=array("table_open"=>'<table class="dataTable table table-condensed table-hover">');
		$heading=array("s.no","dep name","added","action");
		$this->load->library("table");
		$this->table->set_template($tmpl);
		$this->table->set_heading($heading);
		$sn=0;
		foreach ($rec as $row) {
			$disable=(!$row->enable)?"warning":"info";
			$disPath=(!$row->enable)?"enable":"disable";
			$del=anchor("admin/delete/$row->id","delete");
			$dude=anchor("admin/$disPath/$row->id",$disPath);
			$action=<<<HTML
				<div class="btn-group ">
				<button class="btn btn-$disable">action</button>
				<button class="btn dropdown-toggle btn-$disable" data-toggle="dropdown">
					<span class="caret"></span>
				</button>
				<ul class="dropdown-menu">
					<li>$del</li>
					<li>$dude</li>
					
				</ul>
			</div>

HTML;
			$this->table->add_row(++$sn,$row->depName,$row->added,$action);

		}
		$data['dep']=$this->table->generate();
		$this->load->view("admin/template_view",$data);
	}
	
}

 ?>