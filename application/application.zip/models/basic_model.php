<?php  
class Basic_model extends CI_Model{

	var $imagePath;
	function __construct()
	{
		parent::__construct();
		$this->imagePath=realpath(APPPATH.'../img/pic/');

	}
	function insert($tableName,$data)
	{
		
    $newName=$this->fileRename();
		if($newName)
		{
			// echo $this->imagePath;
			
			$uploadConfig=array(
				"upload_path"=>$this->imagePath,
				"file_name"=>$newName,
				"allowed_types"=>"jpeg|jpg|png|gif",
				"max_size"=>"2048" //2 MB
				);
			$this->load->library("upload",$uploadConfig);
			$this->upload->do_upload("photo");
			echo $this->upload->display_errors(); //echo it
			$data['img']=$newName;


		}
		
		$flag=$this->db->insert($tableName,$data);
		return $this->db->insert_id();
	}
  function insertOther($table,$data)
  {
    return $this->db->insert($table,$data);
  }
	function view($tableName,$data=array())
	{
		$this->db->where($data);
		return $this->db->get($tableName)->result();
	}
	function _fields($post,$insertUpdate=0)
  	{
  		$data=array();
  		foreach($post as $key=>$value)
  		{
  			if(!$value)
  				continue;
  			$data[$key]=$value;
  		}
  		$key=(!$insertUpdate)?'added':'updated';
  		$data[$key]=date('Y-m-d h:i:s');
  		return $data;
  	}
  	function fileRename()
  	{
  		if(isset($_FILES['photo']))
  		{
  			
  			$fileName=$_FILES['photo']['name'];
  			$ext=substr($fileName,strrpos($fileName,"."));
  			$this->db->select("id");
  			$this->db->order_by("id","desc");
  			$r=$this->db->get("tbl_employee",1,1);
        $d=$r->result();
        $e=$d[0]->id+1;
  			return $e.$ext;
  		}
  	}
  	function update($tbl,$set)
  	{
  		$id=$this->uri->segment(3);
  		$this->db->where(array("id"=>$id));
  		$this->db->update($tbl,$set);
  	}
  	function upd($tbl,$data)
  	{
  		$this->db->update($tbl,$data);
  	}
    function selectDep($name,$html="")
    {
      $res=$this->db->where(array("enable"=>1,"deleted"=>0))->from("tbl_department")->get()->result();
      $data=array(""=>"");
      foreach ($res as $row) {
        $data[$row->id]=$row->depName;
      }
      return form_dropdown($name,$data,'',$html);

    }
}

 ?>