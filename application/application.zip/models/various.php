<?php  
class Various extends CI_Model{
	

	function label()
	{
		$thisYear=date("Y");
		$whr=array("at"=>1,"deleted"=>0);
		$grp=array("month(date)","year(date)");
		$this->db->from("tbl_attendance");
		$this->db->select("count(id) as 'total',month(date) as  'month' ");
		$this->db->where($whr);
		$this->db->group_by($grp);
		$re=$this->db->get()->result();
		$val=array("month"=>"","value"=>"","year"=>"");
		foreach ($re as $row) {
			$val["month"].=','.date("M",strtotime("2013-$row->month-1"));
			$val["value"].=','.$row->total;

		}
		$val["month"]=trim($val["month"],",");
		$val["value"]=trim($val["value"],",");
		return $val;


	}
	function userStat()
	{
		$thisYear=date("Y");
		$whr=array("deleted"=>0,"year(added)"=>$thisYear,);
		$grp=array("month(added)","year(added)");
		$this->db->from("tbl_employee");
		$this->db->select("count(id) as 'total',month(added) as  'month' ,year(added) as 'year' ");
		$this->db->where($whr);
		$this->db->group_by($grp);
		$re=$this->db->get()->result();
		$val=array("month"=>"","value"=>"","year"=>"");
		foreach ($re as $row) {
			$val["month"].=','.date("M",strtotime("2013-$row->month-1"));
			$val["value"].=','.$row->total;
			$val["year"].=','.date("Y",strtotime("$row->year-01-1"));

		}
		$val["month"]=trim($val["month"],",");
		$val["value"]=trim($val["value"],",");
		$val["year"]=trim($val["year"],",");
		// echo $this->db->last_query();exit;
		return $val;

	}
	function monthSelect()
	{
		$month=range(1,12);
		$select=array(""=>"");
		foreach ($month as $val) {
			$select[$val]=date("M",strtotime("2013-$val-01"));
			/*if($val==date("m"))
				$def=$val;*/
		}
		return form_dropdown('month',$select,"",'class="input-small"');
	}
	function month()
	{
		$month=range(1,12);
		$select=array('day');
		foreach ($month as $val) {
			$select[]=date("M",strtotime("2013-$val-01"));
			
		}
		return $select;
	}
	function yearSelect()
	{
		$year=range(2012,2099);
		$select=array();
		foreach ($year as $val) {
			$select[$val]=$val;
		}
		return form_dropdown('year',$select,date("Y"),'class="input-small"');
	}
	function defAt()
	{
		
		
		$month=($this->input->post("month"))?$this->input->post("month"):date('m');
		$year=($this->input->post("year"))?$this->input->post("year"):date('Y');
		$empID=$this->session->userdata("empID");
		$grp=array("date");
		$whr=array("empID"=>$empID,"enable"=>1,"deleted"=>0,"year(date)"=>$year);
		$res=$this->db->select("empID,month(date) as 'month',day(date) as 'day',at ")
					->from("tbl_attendance")->where($whr)->group_by($grp)->get()->result();
		// echo $this->db->last_query();exit;
		$presentMonth=array(); //will have the months for which the usr was prsent
		$p=$a=0;
		foreach ($res as $row) {

			$presentMonth[$row->month][$row->day]=$row->at;
			if($row->at==1)
				$p++;
			else
				$a++;
		}
		$tmpl=array("table_open"=>'<table class="table table-condensed table-hover">');

		$heading=$this->month();
		$this->load->library("table");
		$this->table->set_template($tmpl);
		$at=array(0=>"",1=>'<span class="ui-text-green">p</span>',2=>'<span class="ui-text-red">a</span>');
		$this->table->set_heading($heading);
		for($x=1;$x<=31;$x++)
		{
			//$this->table->add_row($x,'p','p','p','p','p','a','p','p','p','p','a','a');			
			$row=array($x);
			for($y=1;$y<=12;$y++)
			{
				if(isset($presentMonth[$y][$x]))
					$row[]=$at[$presentMonth[$y][$x]];
				else
					$row[]='--';
			}
			$this->table->add_row($row);
		}
		$data["year"]=$year;
		$data["month"]=$month;
		$data["p"]=$p;
		$data["a"]=$a;
		$data["table"]=$this->table->generate();
		return  $data;

	}
	function viewAtt()
	{

	}
}

 ?>