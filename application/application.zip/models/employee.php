<?php  
class Employee extends CI_Model{
	public $table;
	function __construct()
	{
		parent::__construct();
		$this->table="employee";
	}
	function listEmployee($filter=array())
	{
		$this->db->select("emp.*,dep1.depName as 'dep1Name',dep2.depName as 'dep2Name' ");
		$filter["emp.deleted"]=0;
		if($this->input->post("filterSex"))
			$filter["sex"]=$this->input->post("filterSex");
		if($this->input->post("filterMar"))
			$filter['maritalStatus']=$this->input->post("maritalStatus");
		if($this->input->post("addedFrom"))
			$filter['date(emp.added)>=']=$this->input->post("addedFrom");
		if($this->input->post("addedTo"))
			$filter['date(emp.added)<=']=$this->input->post("addedTo");
		if($this->input->post("filterAppType"))
			$filter["empType"]=$this->input->post("filterAppType");
		if($this->input->post("filterZipCode"))
			$filter["zip"]=$this->input->post("filterZipCode");
		if($this->input->post("filterCity"))
			$filter["city"]=$this->input->post("filterCity");
		if($this->input->post("filterState"))
			$filter["state"]=$this->input->post("filterState");
		if($this->input->post("filterEmail"))
			$filter["email"]=$this->input->post("filterEmail");
		$this->db->where($filter);
		if($this->input->post("filterName"))
			{
				$name=$this->input->post("filterName");
				$this->db->where("(firstName like '%$name%' or lastName like '%$name%')");
				
			}
		if($this->input->post("filterDepName"))
			{
				$name=$this->input->post("filterDepName");
				$this->db->where("(dep1='$name' or dep2='$name')");
			}
		$this->db->from("tbl_employee as emp");
		$this->db->join("tbl_department as dep1","emp.dep1=dep1.id","left");
		$this->db->join("tbl_department as dep2","emp.dep2=dep2.id","left");			

		$q=$this->db->get()->result();
		 // echo $this->db->last_query();exit;
		return $q;

	}
	function saveAttend()
	{
		$emp=$this->input->post("emp");
		$date=$this->input->post("dateTime");
		$values=array();
		$flag=0;
		foreach($emp as $value)
		{
			$empID=$value;
			$at=$this->input->post("at$empID");
			$res=($this->db->where(array("empID"=>$empID,"date"=>$date))->from("tbl_attendance")->get()->result());
			foreach ($res as $row) {
				$flag=1;
			}
			if($flag)
				continue;
			if(!$at)
				continue;
			$values[]=array("date"=>$date,"empID"=>$empID,"at"=>$at,"added"=>date("Y-m-d h:i:s"));

		}
		return($values)?$this->db->insert_batch("tbl_attendance",$values):0;
		
	}
	function viewAttend()
	{
		$date=$this->uri->segment(3);
		$this->db->where(array("date(at.added)"=>$date,"at.enable"=>1,"at.deleted"=>0));
		$this->db->from("tbl_attendance as at");
		$this->db->join("tbl_employee as emp","emp.id=at.empID");
		$attend=$this->db->get()->result();

		$sn=0;
		$p=array("",'checked="checked"',"");
		$a=array("","",'checked="checked"');
    	foreach ($attend as $row) {
    		if($row->firstName=="" && $row->lastName=="")
    			continue;
    		$name="at".$row->id;
    		$img="45.jpg";
    		//echo $row->at;
       		?>

    		<div class="row top-buffer-small">
    			<input type="hidden" name="emp[]" value="<?php echo  $row->id ?>">
    			<div class="span1"><?php echo ++$sn ?></div>
    			<div class="span1"><?php  echo img("img/pic/".$img) ?></div>
    			<div class="span3"><?php echo $row->firstName.' '.$row->lastName ?></div>
	    		<div class="span3">
	    			<input class="hidden-x" type="radio" value="1" 
	    					id="p<?php echo $row->id?>" name="<?php echo $name ?>" <?php  echo $p[$row->at] ?>> 
    				<label class=" padding-small checkLabel radioHidden ui-blue text-center" 
    						for="p<?php echo $row->id?>">present</label>
					
		    	</div>
	    		<div class="span3">
	    			<input class="hidden-x" type="radio" value="2" id="a<?php echo $name ?>"  
	    				name="<?php echo $name ?>" <?php  echo $a[$row->at] ?> > 
		    		<label class=" padding-small checkLabel radioHidden ui-red text-center" 
		    				for="a<?php echo $row->id?>">absent</label>
	    		</div>
    		</div>

    	<?php }
	
	}
	function fetchNSaveDep()
	{
		
		if(($this->input->post("depName")))
		{
			$this->db->insert("tbl_department",array("depName"=>$this->input->post("depName"),"added"=>date('Y-m-d h:i:s')));
		}
		
		$this->db->where(array("deleted"=>0));
		$this->db->order_by("id","DESC");
		$rec=$this->db->get("tbl_department")->result();
		return $rec;
	}
	function returnEmployee($data)
	{
		$r=$this->db->from("tbl_employee")->where($data)->get()->result();
		return $r[0];

	}
	

} 


?>