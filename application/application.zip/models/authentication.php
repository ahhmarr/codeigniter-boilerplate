<?php  
class Authentication extends CI_Model{
	function verify($data)
	{
      	$this->db->where($data);
      	$result=$this->db->get("users");
      	if($result->num_rows==1)
      	{
      		$r=$result->result();
                  $userType=$r[0]->userType;
                  $data["who"]=$userType;
                  $data["userID"]=$r[0]->id;
                  $data["empID"]=$r[0]->empID;
                  $config["lastIP"]=$this->input->ip_address();
                  $config['lastLogin']=date("Y-m-d h:i:s");
                  $this->update("users",$config,$r[0]->id);
      		$this->session->set_userdata($data);
      	}
      	
            return $result->num_rows;


      		
	}
      function update($table,$data,$id)
      {
            $this->db->where(array("id"=>$id));
            $this->db->update($table,$data);
      }
} 


 ?>